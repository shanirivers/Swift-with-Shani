//: Playground - noun: a place where people can play

import SpriteKit
import XCPlayground


// Classes and Inheritance


// Create the SpriteKit View

let frame = CGRect(x: 0, y: 0, width: 1024, height: 1024)

// Set middle point 

let midPoint = CGPoint (x: frame.size.width / 2, y: frame.size.height / 2)

// Set the scene

var scene = SKScene(size: frame.size)



/// THE HARD WAY
//let aSunSprite: SKSpriteNode = SKSpriteNode(color: NSColor.purpleColor(), size: CGSizeMake(100, 100))
//
//let spritePosition = CGPoint(x: 200, y: 200)
//aSunSprite.position = spritePosition
//
//aSunSprite.runAction(SKAction.repeatActionForever(SKAction.rotateByAngle(6, duration: 3)))
//
//scene.addChild(aSunSprite)
//
//let aRedSprite: SKSpriteNode = SKSpriteNode(color: NSColor.redColor(), size: CGSizeMake(100, 100))
//
//let spriteRedPosition = CGPoint(x: 200, y: 200)
//aRedSprite.position = midPoint
//
//aRedSprite.runAction(SKAction.repeatActionForever(SKAction.rotateByAngle(6, duration: 3)))
//
//scene.addChild(aRedSprite)

// CREATE SOME STARS OR GALAXIES
let emitGalaxies = SKEmitterNode()
emitGalaxies.particleLifetime = 40
emitGalaxies.particleBlendMode = SKBlendMode.Alpha
emitGalaxies.particleBirthRate = 5
emitGalaxies.particleSize = CGSize(width: 3, height: 3)
emitGalaxies.particleColor = SKColor.whiteColor()
emitGalaxies.position = CGPoint(x:frame.size.width,y:midPoint.y)
emitGalaxies.particleSpeed = 16
emitGalaxies.particleSpeedRange = 100
emitGalaxies.particlePositionRange = CGVector(dx: 0, dy: frame.size.height)
emitGalaxies.emissionAngle = 3.14
emitGalaxies.advanceSimulationTime(40)
emitGalaxies.particleAlpha = 0.5
emitGalaxies.particleAlphaRange = 0.5
scene.addChild(emitGalaxies)


// CREATE CELESTIAL BODY CLASS

class Body: SKSpriteNode {

    
    func spawn (parentNode: SKNode, texture: SKTexture, position: CGPoint, color: NSColor, size: CGSize = CGSizeMake(100, 100)) {
        /// Add the sprite to the scene
        parentNode.addChild(self)
        
        /// Create a sprite
        self.texture = texture
        self.size = size
        self.color = color
        
        /// Set the position of the sprite
        self.position = position
        
    }
    
    // Add animation
    func rotateAnimation (angle: CGFloat, duration: NSTimeInterval) {
        /// To have the sprite do an action
        self.runAction(SKAction.repeatActionForever(SKAction.rotateByAngle(angle, duration: duration)))
        
    }
}

let sun = Body()
sun.spawn(scene, texture: SKTexture(imageNamed: "sun-hd.png"), position: midPoint, color: NSColor.yellowColor())
sun.rotateAnimation(3, duration: 4)

// Planets
let mercury = Body()
mercury.spawn(sun, texture: SKTexture(imageNamed: "mercury.png"), position: CGPoint(x: frame.size.width/8, y: frame.size.width/8), color: NSColor.redColor(), size: CGSizeMake(30, 30))
mercury.rotateAnimation(4, duration: 3)

//let venus = Body()
//venus.spawn(sun, position: CGPoint(x: 200, y: -200), color: NSColor.orangeColor(), size: CGSize(width: 50, height: 50))
//venus.rotateAnimation(1.2, duration: 2)


// Show scene 
let view = SKView(frame: frame)

// Present scene
view.presentScene(scene)

// Show this in the assistant editor
//XCPlaygroundPage.currentPage.liveView = view









